#!/usr/bin/env python3

from libgreen import *

broadcast_file("/home/aswin/tmp/sample.txt")
