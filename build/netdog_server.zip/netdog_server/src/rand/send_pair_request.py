#!/usr/bin/env python3
from libgreen import send_data

send_data("127.0.0.1", 1337, "Project-1,pair,sample_rsa_public_key")
